# توثيق الـ API

العنوان الأساسي محلياً: `http://localhost:8000`. التوثيق التفاعلي (Swagger UI): `/docs`، ومخطط OpenAPI: `/openapi.json`.

## المصادقة (اختيارية)

إن ضبطت `API_KEY` في `.env` فكل المسارات تتطلب المفتاح **عدا** `/` و`/health` و`/static/*`:

```bash
curl -H "X-API-Key: YOUR_KEY" http://localhost:8000/tools
```

مفتاح خاطئ أو مفقود ← `401`:

```json
{"detail": "Invalid or missing API key"}
```

## تحديد المعدل

الحد العام `RATE_LIMIT` (افتراضي `60/minute` لكل IP) و`CHAT_RATE_LIMIT` (`20/minute`) لـ `/chat`. عند التجاوز ← `429`:

```json
{"error": "Rate limit exceeded: 1 per 1 minute"}
```

---

## `GET /health`

فحص الصحة. عام ومعفى من تحديد المعدل (يُستعمل في Docker healthcheck).

```bash
curl http://localhost:8000/health
```

```json
{"status": "ok", "device": "cuda", "stt_loaded": true, "tts_loaded": true}
```

| الحقل | المعنى |
|---|---|
| `device` | `cuda` أو `cpu` |
| `stt_loaded` / `tts_loaded` | هل حُمّل النموذج في الذاكرة بعد |

## `GET /tools`

الأدوات التي يستطيع النموذج استدعاءها.

```bash
curl http://localhost:8000/tools
```

```json
{
  "count": 2,
  "tools": [
    {
      "name": "get_current_time",
      "description": "الحصول على التاريخ والوقت الحاليين. يمكن تمرير timezone اختيارياً.",
      "parameters_schema": {
        "type": "object",
        "properties": {"timezone": {"type": "string", "description": "اسم المنطقة الزمنية مثل Asia/Riyadh"}},
        "required": []
      },
      "is_async": false
    },
    {"name": "book_appointment", "...": "..."}
  ]
}
```

## `POST /chat`

محادثة نصية. لكل `session_id` سجل منفصل (يُحفظ في الذاكرة، حد أقصى 100 جلسة، والأقدم يُحذف أولاً).

| الحقل | النوع | الشرح |
|---|---|---|
| `message` | string، 1–2000 حرف | **مطلوب.** رسالة المستخدم |
| `session_id` | string، `[A-Za-z0-9_-]`، حتى 64 | اختياري، الافتراضي `default` |
| `reset` | bool | اختياري. `true` يمسح سجل الجلسة قبل الرد |

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_KEY" \
  -d '{"message": "مرحبا، كم الساعة الآن؟", "session_id": "demo"}'
```

```json
{"session_id": "demo", "reply": "أهلاً بك! الساعة الآن ..."}
```

رسالة فارغة ← `422`:

```json
{"detail": [{"type": "string_too_short", "loc": ["body", "message"], "msg": "String should have at least 1 character", "input": "", "ctx": {"min_length": 1}}]}
```

إن تعذّر الوصول إلى Ollama يعيد الخادم `200` ونص اعتذار في `reply` (سلوك `backend/llm.py`).

## `WS /ws`

بث صوتي ثنائي الاتجاه.

- **الاتصال:** `ws://localhost:8000/ws` (أو `?api_key=YOUR_KEY` عند تفعيل المصادقة؛ مفتاح خاطئ ← إغلاق بالرمز `1008`).
- **العميل ← الخادم:** إطارات ثنائية **PCM 16-bit mono 16kHz** بطول **30ms** (960 بايت) بالضبط.
- **الخادم ← العميل:** رسائل JSON:

| `type` | الحقول | المعنى |
|---|---|---|
| `status` | `msg` | الحالة: «أستمع...»، «أحوّل الكلام لنص...»، «أفكر...»، «جاهز» |
| `user` | `text` | ما فهمه STT |
| `assistant` | `text` | رد النموذج |
| `audio` | `url` | مسار ملف الرد، مثل `/audio/<uuid>_reply.wav` |
| `error` | `msg` | خطأ (STT أو TTS أو غياب `assistant_ref.wav`) |

كل اتصال له سجل محادثة مستقل. مثال بـ [websocat](https://github.com/vi/websocat): `websocat ws://localhost:8000/ws`.

## `GET /audio/{name}`

ينزّل ملف الرد الصوتي الذي أرجعه `/ws`.

```bash
curl -o reply.wav "http://localhost:8000/audio/<uuid>_reply.wav?api_key=YOUR_KEY"
```

- `200` مع `audio/wav`.
- `404` إذا لم يوجد الملف أو كان الاسم يحاول الخروج من مجلد `tmp/`:

```json
{"detail": "Audio not found"}
```
