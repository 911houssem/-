# -*- coding: utf-8 -*-
"""
نقطة دخول FastAPI للمساعد الصوتي العربي.

المسارات:
  GET  /          الواجهة الأمامية
  GET  /health    فحص الصحة (عام، بدون مصادقة، معفى من تحديد المعدل)
  GET  /tools     قائمة الأدوات المسجلة
  POST /chat      محادثة نصية مع النموذج اللغوي
  WS   /ws        بث صوتي: صوت -> STT -> LLM -> TTS
  GET  /audio/x   تنزيل ملف الرد الصوتي
"""

import asyncio
import secrets
import uuid
import wave
from collections import OrderedDict
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, WebSocket
from fastapi import WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

# استيراد طبقة الأدوات لضمان تسجيلها
from . import tools  # noqa: F401
from .config import FRONTEND_DIR, TMP_DIR, settings
from .llm import LLM
from .loader import loader
from .vad import VAD

# ---------------------------------------------------------------------------
# تحديد المعدل (Rate Limiting)
# ---------------------------------------------------------------------------
# lambda: تُقرأ القيمة عند كل طلب، فيمكن تغييرها بدون إعادة بناء التطبيق.
# خلف Nginx/Cloudflare شغّل uvicorn بـ --proxy-headers كي يرى IP العميل الحقيقي.
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[lambda: settings.RATE_LIMIT],
    enabled=settings.RATE_LIMIT_ENABLED,
)


# ---------------------------------------------------------------------------
# المصادقة بمفتاح API (اختيارية)
# ---------------------------------------------------------------------------
def _key_is_valid(provided: Optional[str]) -> bool:
    """إن لم يُضبط API_KEY فالمصادقة معطّلة. المقارنة بزمن ثابت لمنع هجمات التوقيت."""
    if not settings.API_KEY:
        return True
    return bool(provided) and secrets.compare_digest(provided, settings.API_KEY)


async def require_api_key(
    x_api_key: Optional[str] = Header(default=None),
    api_key: Optional[str] = Query(default=None),  # لوسوم <audio> التي لا ترسل ترويسات
):
    if not _key_is_valid(x_api_key or api_key):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


# ---------------------------------------------------------------------------
# جلسات المحادثة النصية (/chat): كل جلسة لها سجل منفصل. الحد الأقصى يمنع تضخم الذاكرة.
# ---------------------------------------------------------------------------
MAX_SESSIONS = 100
_sessions: "OrderedDict[str, LLM]" = OrderedDict()


def get_session(session_id: str) -> LLM:
    if session_id in _sessions:
        _sessions.move_to_end(session_id)
        return _sessions[session_id]
    if len(_sessions) >= MAX_SESSIONS:
        _sessions.popitem(last=False)  # إزالة الأقدم
    _sessions[session_id] = LLM()
    return _sessions[session_id]


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000, description="نص رسالة المستخدم")
    session_id: str = Field(
        default="default",
        max_length=64,
        pattern=r"^[A-Za-z0-9_-]+$",
        description="معرّف الجلسة لحفظ سياق المحادثة",
    )
    reset: bool = Field(default=False, description="مسح سجل الجلسة قبل الرد")


class ChatResponse(BaseModel):
    session_id: str
    reply: str


# ---------------------------------------------------------------------------
# التطبيق
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(_app: FastAPI):
    if settings.PRELOAD_MODELS:
        print("[STARTUP] Preloading models...")
        for name, fn in (("STT", loader.load_stt), ("TTS", loader.load_tts)):
            try:
                fn()
            except Exception as e:  # الخادم يعمل حتى لو فشل نموذج (يظهر الخطأ للعميل)
                print(f"[STARTUP][WARN] {name} load failed: {e}")
    for name, tool in tools.tool_registry.list_tools().items():
        print(f"[STARTUP] tool: {name} - {tool.description}")
    print("[STARTUP] Ready")
    yield


app = FastAPI(title="Voice Agent - Cloud Ready", version="1.1.0", lifespan=lifespan)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# CORS: قيّد CORS_ORIGINS في الإنتاج، مثال: https://app.example.com,https://admin.example.com
# ملاحظة: allow_credentials=False عمداً، فالمصادقة هنا بمفتاح وليس بكوكيز.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-API-Key"],
)

app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


@app.get("/", response_class=HTMLResponse)
async def index():
    html_path = FRONTEND_DIR / "index.html"
    return HTMLResponse(content=html_path.read_text(encoding="utf-8"))


@app.get("/health")
@limiter.exempt  # فحوص Docker/Kubernetes المتكررة يجب ألا تُحجب
async def health():
    return {
        "status": "ok",
        "device": loader.device,
        "stt_loaded": loader.stt is not None,
        "tts_loaded": loader.tts is not None,
    }


@app.get("/tools", dependencies=[Depends(require_api_key)])
async def list_tools():
    result = [
        {
            "name": tool.name,
            "description": tool.description,
            "parameters_schema": tool.parameters_schema,
            "is_async": tool.is_async,
        }
        for tool in tools.tool_registry.list_tools().values()
    ]
    return {"count": len(result), "tools": result}


@app.post("/chat", response_model=ChatResponse, dependencies=[Depends(require_api_key)])
@limiter.limit(lambda: settings.CHAT_RATE_LIMIT)  # يتطلب معامل request أدناه
async def chat(request: Request, body: ChatRequest):
    session = get_session(body.session_id)
    if body.reset:
        session.reset()
    reply = await session.chat(body.message)
    return ChatResponse(session_id=body.session_id, reply=reply)


@app.get("/audio/{name}", dependencies=[Depends(require_api_key)])
async def get_audio(name: str):
    # حماية من Path Traversal: الاسم يجب أن يكون اسم ملف فقط وداخل TMP_DIR
    path = (TMP_DIR / name).resolve()
    if Path(name).name != name or path.parent != TMP_DIR.resolve() or not path.is_file():
        raise HTTPException(status_code=404, detail="Audio not found")
    return FileResponse(path, media_type="audio/wav")


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    # المتصفح لا يضيف ترويسات مخصصة للـ WebSocket، لذا نقبل المفتاح من الترويسة أو من ?api_key=
    provided = ws.headers.get("x-api-key") or ws.query_params.get("api_key")
    if not _key_is_valid(provided):
        await ws.close(code=1008)  # Policy Violation
        return

    await ws.accept()
    llm = LLM()  # سجل محادثة مستقل لكل اتصال (لا يتشارك بين المستخدمين)
    vad = VAD(settings.VAD_AGGRESSIVENESS, settings.CHUNK_MS, settings.SAMPLE_RATE)
    audio_buffer = bytearray()
    recording = False
    silence_frames = 0
    max_silence = int(settings.SILENCE_TIMEOUT_MS / settings.CHUNK_MS)
    max_bytes = int(settings.MAX_UTTERANCE_SEC * settings.SAMPLE_RATE * 2)

    try:
        while True:
            data = await ws.receive_bytes()
            if not recording:
                if vad.is_speech(data):
                    recording = True
                    audio_buffer.clear()
                    audio_buffer.extend(data)
                    await ws.send_json({"type": "status", "msg": "أستمع..."})
                continue

            audio_buffer.extend(data)
            silence_frames = 0 if vad.is_speech(data) else silence_frames + 1
            if silence_frames < max_silence and len(audio_buffer) < max_bytes:
                continue

            # --- انتهى الكلام: احفظ ثم STT -> LLM -> TTS ---
            in_wav = TMP_DIR / f"{uuid.uuid4()}.wav"
            with wave.open(str(in_wav), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(settings.SAMPLE_RATE)
                wf.writeframes(bytes(audio_buffer))
            await ws.send_json({"type": "status", "msg": "أحوّل الكلام لنص..."})
            text = ""
            try:
                stt = loader.load_stt()
                # to_thread: الاستدلال متزامن وثقيل، فلا نحجب حلقة الأحداث
                text = await asyncio.to_thread(stt.transcribe_wav, str(in_wav))
            except Exception as e:
                await ws.send_json({"type": "error", "msg": f"خطأ STT: {e}"})
            finally:
                in_wav.unlink(missing_ok=True)  # لا نحتفظ بتسجيلات المستخدمين

            if text.strip():
                await ws.send_json({"type": "user", "text": text})
                await ws.send_json({"type": "status", "msg": "أفكر..."})
                answer = await llm.chat(text)
                await ws.send_json({"type": "assistant", "text": answer})
                await ws.send_json({"type": "status", "msg": "أُجيب صوتياً..."})
                out_wav = TMP_DIR / f"{uuid.uuid4()}_reply.wav"
                try:
                    ref_audio = Path(settings.REF_AUDIO_PATH)
                    if not ref_audio.exists():
                        await ws.send_json(
                            {
                                "type": "error",
                                "msg": "ضع assistant_ref.wav في assets/ مع REF_TEXT صحيح",
                            }
                        )
                    else:
                        tts = loader.load_tts()
                        await asyncio.to_thread(
                            tts.synthesize,
                            answer,
                            str(ref_audio),
                            settings.REF_TEXT or "",
                            str(out_wav),
                        )
                        await ws.send_json({"type": "audio", "url": f"/audio/{out_wav.name}"})
                except Exception as e:
                    await ws.send_json({"type": "error", "msg": f"خطأ TTS: {e}"})

            recording = False
            silence_frames = 0
            audio_buffer.clear()
            await ws.send_json({"type": "status", "msg": "جاهز"})
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_json({"type": "error", "msg": str(e)})
        except Exception:
            pass  # الاتصال أُغلق أصلاً
