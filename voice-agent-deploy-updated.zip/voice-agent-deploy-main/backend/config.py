# -*- coding: utf-8 -*-
"""إعدادات التطبيق: تُقرأ من متغيرات البيئة أو من ملف .env"""

from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- الخادم ---
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    PRELOAD_MODELS: bool = True  # تحميل STT/TTS عند الإقلاع (عطّله في الاختبارات)

    # --- النموذج اللغوي (Ollama) ---
    OLLAMA_BASE_URL: str = "http://127.0.0.1:11434"
    OLLAMA_MODEL: str = "qwen2.5:7b-instruct"
    OLLAMA_TIMEOUT: int = 180
    ENABLE_TOOLS: bool = True  # عطّلها إن كان النموذج لا يدعم استدعاء الأدوات

    # --- مسارات النماذج ---
    VOXTRAL_MODEL_PATH: str = "/app/models/voxtral-ar"
    SILMA_TTS_DIR: str = "/app/models/silma-tts"

    # --- الصوت ---
    SAMPLE_RATE: int = 16000
    CHUNK_MS: int = 30
    VAD_AGGRESSIVENESS: int = 2
    SILENCE_TIMEOUT_MS: int = 950
    MAX_UTTERANCE_SEC: int = 25

    # --- المساعد ---
    SYSTEM_PROMPT: str = (
        "أنت مساعد صوتي عربي ذكي، تتحدث بشكل طبيعي وواضح، موجزًا عند الحاجة "
        "ومفصلاً عند الطلب. تجيب مباشرة وبأسلوب ودود."
    )
    REF_AUDIO_PATH: str = "/app/assets/assistant_ref.wav"
    REF_TEXT: str = ""

    # --- الأمان ---
    # قائمة أصول (Origins) مفصولة بفواصل. "*" = السماح للجميع (للتطوير فقط).
    CORS_ORIGINS: str = "*"
    # فارغ = المصادقة معطّلة. أي قيمة = مطلوبة في ترويسة X-API-Key.
    API_KEY: str = ""
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT: str = "60/minute"  # الحد العام لكل IP
    CHAT_RATE_LIMIT: str = "20/minute"  # حد أشد لنقطة /chat (تستهلك GPU)

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def cors_origins_list(self) -> List[str]:
        """تحويل CORS_ORIGINS من نص مفصول بفواصل إلى قائمة"""
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()

ROOT = Path(__file__).parent.parent
FRONTEND_DIR = ROOT / "frontend"
ASSETS_DIR = ROOT / "assets"
TMP_DIR = ROOT / "tmp"

for _p in (ASSETS_DIR, TMP_DIR):
    _p.mkdir(exist_ok=True)
