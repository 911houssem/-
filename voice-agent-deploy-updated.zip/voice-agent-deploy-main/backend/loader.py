# -*- coding: utf-8 -*-
"""تحميل نماذج STT/TTS بشكل كسول (Lazy) ومرة واحدة فقط"""

from .config import settings


def _detect_device() -> str:
    """cuda إن توفر، وإلا cpu. الاستيراد متأخر كي تعمل الاختبارات بدون torch."""
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


class ModelLoader:
    def __init__(self):
        self.stt = None
        self.tts = None
        self.device = _detect_device()
        print(f"[LOADER] Device: {self.device}")

    def load_stt(self):
        if self.stt is not None:
            return self.stt
        from .stt_voxtral import VoxtralSTT

        print(f"[LOADER] Loading Voxtral from {settings.VOXTRAL_MODEL_PATH}")
        self.stt = VoxtralSTT(settings.VOXTRAL_MODEL_PATH)
        print("[LOADER] Voxtral loaded")
        return self.stt

    def load_tts(self):
        if self.tts is not None:
            return self.tts
        from .tts_silma import SilmaTTS

        print(f"[LOADER] Loading SilmaTTS from {settings.SILMA_TTS_DIR}")
        self.tts = SilmaTTS(settings.SILMA_TTS_DIR)
        print("[LOADER] SilmaTTS loaded")
        return self.tts


loader = ModelLoader()
