<div align="center">

# 🎙️ Voice Agent Deploy
### وكيل صوتي عربي متكامل: استماع ← تفكير ← نطق

*An open-source Arabic voice agent: Speech-to-Text → LLM → Text-to-Speech, ready to deploy with Docker or Modal.*

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg?logo=python&logoColor=white)](https://www.python.org/)
[![Docker](https://img.shields.io/badge/Docker-ready-2496ED.svg?logo=docker&logoColor=white)](docker-compose.yml)
[![CI](https://github.com/OWNER/voice-agent-deploy/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/voice-agent-deploy/actions/workflows/ci.yml)

</div>

> استبدل `OWNER` في شارة CI باسم حسابك على GitHub. / Replace `OWNER` in the CI badge with your GitHub username.

## نظرة عامة | Overview

**AR:** مساعد صوتي يعمل بالكامل على بنيتك التحتية (بدون إرسال الصوت لجهات خارجية). تتحدث بالعربية، فيحوّل **Voxtral Mini 4B Realtime** كلامك إلى نص، ويفكر **Ollama** (Qwen2.5 أو Jais) في الرد، وينطقه **SILMA TTS v1** بصوت مستنسخ من ملف مرجعي. يتضمن طبقة أدوات (Function Calling)، وواجهة ويب، وواجهة REST/WebSocket.

**EN:** A self-hosted Arabic voice assistant. Voxtral transcribes speech, an Ollama-served LLM (Qwen2.5 or Jais) generates the reply, and SILMA TTS speaks it using a cloned reference voice. Includes tool calling, a web UI, and REST/WebSocket APIs.

## المعمارية | Architecture

```mermaid
flowchart LR
    U["🎤 المستخدم / User<br/>Browser mic (PCM 16kHz)"] -- "WebSocket /ws" --> V["VAD<br/>webrtcvad"]
    V -- "جملة كاملة / utterance" --> A["ASR<br/>Voxtral Mini 4B"]
    A -- "نص / text" --> L["LLM<br/>Ollama (Qwen2.5 / Jais)"]
    L <-- "Function calling" --> T["🛠️ Tools<br/>backend/tools"]
    L -- "رد نصي / reply" --> S["TTS<br/>SILMA TTS v1"]
    S -- "WAV /audio/…" --> U
    C["curl / تطبيقك"] -- "POST /chat" --> L
```

## البدء السريع | Quick Start (Docker)

**المتطلبات المسبقة | Prerequisites:** Docker 24+ مع [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html)، وبطاقة NVIDIA. ضع النماذج في المجلد التالي قبل التشغيل (لا تُرفع إلى Git):

```text
models/
├── voxtral-ar/     # أوزان Voxtral Mini 4B Realtime (عربي)
└── silma-tts/      # مستودع SILMA TTS (يحتوي src/)
assets/assistant_ref.wav   # صوت مرجعي 5-15 ثانية (+ نصه في REF_TEXT)
```

```bash
# 1) الإعداد: انسخ ملف البيئة وعدّل REF_TEXT و OLLAMA_MODEL عند الحاجة
cp .env.example .env

# 2) التشغيل (يبني الصورة ويسحب نموذج Ollama تلقائياً في أول مرة)
docker compose up -d --build        # أو:  make run
```

افتح **http://localhost:8000** واضغط زر الميكروفون. أول إقلاع بطيء (تحميل النماذج)؛ تابعه بـ `make logs`.

## متطلبات العتاد | Hardware Requirements

| المكوّن | النموذج | VRAM تقريبي | ملاحظات |
|---|---|---|---|
| ASR | Voxtral Mini 4B Realtime | ≈ 8–10 GB (bf16) | على CPU يعمل لكنه أبطأ بكثير من الزمن الحقيقي |
| LLM | Qwen2.5-7B-Instruct (Ollama، تكميم Q4) | ≈ 5–6 GB | 14B ≈ 10–12 GB |
| LLM | Jais (حسب الحجم) | حسب الحجم والتكميم | تحقق من حجم النموذج في Ollama |
| TTS | SILMA TTS v1 | ≈ 2–4 GB | يزداد قليلاً مع طول النص |
| **المجموع المقترح** | الثلاثة على بطاقة واحدة | **24 GB VRAM** (مثل A10G / RTX 4090) | RAM ≥ 16 GB وقرص ≥ 40 GB |

> ⚠️ الأرقام **تقديرية**. قِس الاستهلاك الفعلي على جهازك بـ `nvidia-smi` قبل الاعتماد عليها. إن ضاقت الذاكرة فشغّل Ollama على جهاز/بطاقة منفصلة عبر `OLLAMA_BASE_URL`.

## تغيير النماذج | Switching Models

كل شيء عبر ملف `.env`، ثم `make restart`.

**من Qwen إلى نموذج آخر موجود في مكتبة Ollama:**

```env
OLLAMA_MODEL=qwen2.5:14b-instruct
```

**إلى Jais** (إن لم يتوفر له وسم جاهز في Ollama، استورد ملف GGUF بنفسك):

```bash
# Modelfile (داخل مجلد فيه ملف GGUF)
#   FROM ./jais-model-q4.gguf
docker compose exec ollama ollama create jais3 -f /root/.ollama/Modelfile
```

```env
OLLAMA_MODEL=jais3
OLLAMA_AUTO_PULL=false   # النموذج مستورد محلياً، فلا تحاول سحبه
ENABLE_TOOLS=false       # عطّلها إن كان النموذج لا يدعم Function Calling
```

## الأمان | Security

| الميزة | الإعداد في `.env` | الشرح |
|---|---|---|
| CORS | `CORS_ORIGINS` | الافتراضي `*` للتطوير. في الإنتاج: `https://app.example.com,https://admin.example.com` |
| مفتاح API | `API_KEY` | فارغ = معطّل. عند ضبطه أرسل `X-API-Key` (أو `?api_key=` للـ WebSocket والصوت). `/` و`/health` يبقيان عامّين |
| تحديد المعدل | `RATE_LIMIT` / `CHAT_RATE_LIMIT` | لكل IP، مثل `60/minute`. `/health` معفى. الرد عند التجاوز: `429` |

- خلف Nginx/Cloudflare يحدد المعدل حسب IP العميل الحقيقي لأن `start.sh` يشغّل uvicorn بـ `--proxy-headers`. تأكد أن الوكيل يمرر `X-Forwarded-For`.
- لا تكشف منفذ Ollama (`11434`) للإنترنت؛ لا يملك مصادقة (مربوط بـ `127.0.0.1` في `docker-compose.yml`).
- المفتاح في الرابط (`?api_key=`) يظهر في سجلات الخوادم. استعمل ترويسة `X-API-Key` لأي عميل غير المتصفح.

## توثيق الـ API | API

الملخص: `GET /health` · `GET /tools` · `POST /chat` · `WS /ws` · `GET /audio/{name}`. الأمثلة الكاملة بـ curl والاستجابات في **[docs/API.md](docs/API.md)**، والتوثيق التفاعلي (Swagger) على `http://localhost:8000/docs`.

## التطوير والاختبار | Development

```bash
make install-dev   # أدوات التطوير + pre-commit
make test          # pytest (بدون GPU: النماذج مُستبدلة بـ Mocks)
make lint          # black --check + flake8
make format        # تنسيق تلقائي
```

## النشر على Modal | Modal (Serverless)

انظر [README_MODAL.md](README_MODAL.md). للسحابة العامة (RunPod / Vast.ai) انظر [README_CLOUD.md](README_CLOUD.md).

## المساهمة | Contributing

المساهمات مرحّب بها! اقرأ **[CONTRIBUTING.md](CONTRIBUTING.md)** قبل فتح Pull Request.

## الترخيص | License

[MIT](LICENSE) للكود. **أوزان النماذج** (Voxtral، SILMA TTS، Qwen، Jais) لها تراخيصها الخاصة؛ راجعها قبل أي استخدام تجاري.
