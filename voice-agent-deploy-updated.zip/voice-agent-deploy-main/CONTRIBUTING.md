# المساهمة | Contributing

شكراً لاهتمامك! / Thanks for your interest!

## الإعداد المحلي

```bash
git clone https://github.com/OWNER/voice-agent-deploy.git && cd voice-agent-deploy
python -m venv .venv && source .venv/bin/activate    # ويندوز: .venv\Scripts\activate
make install-dev                                     # أدوات التطوير + pre-commit
make test                                            # يجب أن تنجح كلها بدون GPU
```

## سير العمل

1. افتح Issue يصف الخلل أو الميزة (أو علّق على Issue موجود).
2. أنشئ فرعاً: `git checkout -b feat/اسم-قصير` أو `fix/اسم-قصير`.
3. اكتب الكود **مع اختبار** له في `tests/`. استبدل النماذج الثقيلة بـ Mocks (انظر `tests/conftest.py`).
4. شغّل `make format && make lint && make test`. نفس هذه الفحوص يشغّلها CI.
5. افتح Pull Request يشرح **ماذا** و**لماذا**.

## معايير الكود

- Python 3.10+، تنسيق `black` (طول السطر 100) و`flake8`.
- لا تضف أسراراً أو نماذج أو ملفات `.wav` إلى Git.
- متغير بيئة جديد؟ أضفه إلى `backend/config.py` و`.env.example` (مع تعليق) والجدول المناسب في README.
- نقطة نهاية جديدة؟ وثّقها في `docs/API.md` وأضف اختباراً لها.
- أداة جديدة للنموذج؟ انظر قسم "كيفية إضافة أداة جديدة" في `README_CLOUD.md`.

## الإبلاغ عن ثغرة أمنية

لا تفتح Issue علنياً. راسل المشرفين بشكل خاص (أو استخدم Security Advisories في GitHub).
