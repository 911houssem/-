#!/usr/bin/env bash
# نقطة بدء الحاوية: يتحقق من النماذج، يسحب نموذج Ollama، ثم يشغّل FastAPI.
set -e

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8000}"
OLLAMA_BASE_URL="${OLLAMA_BASE_URL:-http://127.0.0.1:11434}"
OLLAMA_MODEL="${OLLAMA_MODEL:-qwen2.5:7b-instruct}"

echo "[START] Checking models..."
if [ ! -d "/app/models/voxtral-ar" ] || [ ! -d "/app/models/silma-tts" ]; then
  echo "[WARN] models/ غير مكتملة، سأحاول الربط..."
  python link_models.py || echo "[WARN] تعذّر الربط: ضع voxtral-ar و silma-tts داخل ./models"
fi

# سحب نموذج الـ LLM عبر واجهة Ollama HTTP (يعمل مع خدمة ollama المنفصلة في docker-compose)
if [ "${OLLAMA_AUTO_PULL:-true}" = "true" ]; then
  echo "[START] Waiting for Ollama at ${OLLAMA_BASE_URL} ..."
  for _ in $(seq 1 30); do
    curl -fsS "${OLLAMA_BASE_URL}/api/tags" >/dev/null 2>&1 && break
    sleep 2
  done
  echo "[START] Pulling '${OLLAMA_MODEL}' (قد يستغرق دقائق في المرة الأولى)..."
  curl -fsS "${OLLAMA_BASE_URL}/api/pull" \
    -d "{\"name\": \"${OLLAMA_MODEL}\", \"stream\": false}" >/dev/null \
    || echo "[WARN] تعذّر سحب النموذج (قد يكون مستورداً محلياً أو Ollama غير متاح)"
fi

echo "[START] Launching FastAPI on ${HOST}:${PORT}"
# --proxy-headers: ليرى تحديد المعدل عنوان IP العميل الحقيقي خلف Nginx/Cloudflare
exec uvicorn backend.main:app --host "${HOST}" --port "${PORT}" --workers 1 --proxy-headers
