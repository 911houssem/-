# -*- coding: utf-8 -*-
"""اختبار المسار الكامل صوت -> STT -> LLM -> TTS مع Mocking لكل المكونات الثقيلة."""

from pathlib import Path

from backend import main as main_module
from backend.config import settings


class FakeVAD:
    """VAD وهمي: الإطار الذي يبدأ بالبايت 0x01 يُعدّ كلاماً، وغير ذلك صمتاً."""

    def __init__(self, *args, **kwargs):
        pass

    def is_speech(self, pcm_bytes: bytes) -> bool:
        return pcm_bytes[:1] == b"\x01"


def _collect_until_ready(ws):
    """يقرأ رسائل الخادم حتى يصل إلى حالة 'جاهز' بعد الرد."""
    msgs = []
    while True:
        m = ws.receive_json()
        msgs.append(m)
        if m == {"type": "status", "msg": "جاهز"}:
            return msgs


def test_full_voice_pipeline(client, monkeypatch, tmp_path, mock_llm, mock_models):
    stt, tts = mock_models
    monkeypatch.setattr(main_module, "VAD", FakeVAD)
    ref = tmp_path / "ref.wav"
    ref.write_bytes(b"RIFF....WAVE")  # يكفي وجود الملف
    monkeypatch.setattr(settings, "REF_AUDIO_PATH", str(ref))

    speech = b"\x01" * 960  # إطار 30ms كلام
    silence = b"\x00" * 960  # إطار 30ms صمت
    n_silence = int(settings.SILENCE_TIMEOUT_MS / settings.CHUNK_MS)

    with client.websocket_connect("/ws") as ws:
        ws.send_bytes(speech)
        ws.send_bytes(speech)
        for _ in range(n_silence):
            ws.send_bytes(silence)
        msgs = _collect_until_ready(ws)

    types = [m["type"] for m in msgs]
    assert "user" in types and "assistant" in types and "audio" in types
    assert next(m for m in msgs if m["type"] == "user")["text"] == "مرحبا"
    assert next(m for m in msgs if m["type"] == "assistant")["text"] == "أهلاً بك"
    audio_url = next(m for m in msgs if m["type"] == "audio")["url"]
    assert Path(tmp_path / audio_url.split("/")[-1]).exists()  # ملف الرد أُنشئ فعلاً
    stt.transcribe_wav.assert_called_once()
    tts.synthesize.assert_called_once()
    # تسجيل المستخدم الوارد يُحذف بعد STT (خصوصية)
    assert not [p for p in tmp_path.glob("*.wav") if "_reply" not in p.name and p.name != "ref.wav"]


def test_missing_reference_audio_reports_error(client, monkeypatch, tmp_path, mock_models):
    monkeypatch.setattr(main_module, "VAD", FakeVAD)
    monkeypatch.setattr(settings, "REF_AUDIO_PATH", str(tmp_path / "nope.wav"))
    n_silence = int(settings.SILENCE_TIMEOUT_MS / settings.CHUNK_MS)

    with client.websocket_connect("/ws") as ws:
        ws.send_bytes(b"\x01" * 960)
        for _ in range(n_silence + 1):
            ws.send_bytes(b"\x00" * 960)
        msgs = _collect_until_ready(ws)

    assert any(m["type"] == "error" and "assistant_ref.wav" in m["msg"] for m in msgs)
