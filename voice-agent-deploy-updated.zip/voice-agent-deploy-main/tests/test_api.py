# -*- coding: utf-8 -*-
"""اختبارات نقاط النهاية الأساسية (بدون نماذج حقيقية)."""


def test_health_ok(client):
    """/health يعيد 200 وحالة ok دون الحاجة لتحميل أي نموذج."""
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["device"] in ("cpu", "cuda")


def test_index_serves_html(client):
    """الصفحة الرئيسية تُرجع واجهة عربية RTL."""
    r = client.get("/")
    assert r.status_code == 200
    assert 'dir="rtl"' in r.text


def test_tools_listed(client):
    """الأدوات التجريبية الاثنتان مسجلتان (اختبار لخلل التسجيل الذي أُصلح)."""
    r = client.get("/tools")
    assert r.status_code == 200
    names = {t["name"] for t in r.json()["tools"]}
    assert {"get_current_time", "book_appointment"} <= names


def test_chat_returns_mocked_reply(client, mock_llm):
    """/chat يمرر الرسالة للنموذج (الوهمي) ويعيد رده."""
    r = client.post("/chat", json={"message": "مرحبا", "session_id": "s1"})
    assert r.status_code == 200
    assert r.json() == {"session_id": "s1", "reply": "أهلاً بك"}
    mock_llm.assert_awaited_once_with("مرحبا")


def test_chat_rejects_empty_message(client):
    """رسالة فارغة ترفضها Pydantic بـ 422 قبل الوصول للنموذج."""
    r = client.post("/chat", json={"message": ""})
    assert r.status_code == 422


def test_chat_rejects_bad_session_id(client):
    """session_id يقبل أحرفاً وأرقاماً و - و _ فقط."""
    r = client.post("/chat", json={"message": "hi", "session_id": "../etc"})
    assert r.status_code == 422


def test_chat_sessions_are_isolated(client):
    """كل session_id له سجل LLM مستقل، و reset يمسح السجل."""
    client.post("/chat", json={"message": "a", "session_id": "one"})
    client.post("/chat", json={"message": "b", "session_id": "two"})
    from backend import main

    assert set(main._sessions) == {"one", "two"}
    assert main._sessions["one"] is not main._sessions["two"]
    main._sessions["one"].history.append({"role": "user", "content": "x"})
    client.post("/chat", json={"message": "c", "session_id": "one", "reset": True})
    assert main._sessions["one"].history == []


def test_audio_not_found(client):
    r = client.get("/audio/missing.wav")
    assert r.status_code == 404


def test_audio_served_from_tmp(client, tmp_path):
    (tmp_path / "ok.wav").write_bytes(b"RIFF....WAVE")
    r = client.get("/audio/ok.wav")
    assert r.status_code == 200
    assert r.headers["content-type"] == "audio/wav"


def test_audio_path_traversal_blocked(client):
    """محاولات الخروج من مجلد tmp يجب ألا تُرجع أي ملف (مرمّزة كي لا يطبّعها العميل)."""
    for evil in ("%2e%2e", "%2e%2e%2fsecret", "..%2f..%2fetc%2fpasswd"):
        r = client.get(f"/audio/{evil}")
        assert r.status_code == 404


def test_cors_headers_present(client):
    """مع CORS_ORIGINS=* يعاد الترويس للأصل القادم من المتصفح."""
    r = client.get("/health", headers={"Origin": "https://example.com"})
    assert r.headers.get("access-control-allow-origin") == "*"
