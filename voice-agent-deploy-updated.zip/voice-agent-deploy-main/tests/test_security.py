# -*- coding: utf-8 -*-
"""اختبارات الأمان: مفتاح API وتحديد المعدل."""

import pytest
from starlette.websockets import WebSocketDisconnect

from backend.config import settings


def test_api_key_disabled_by_default(client):
    """بدون API_KEY في الإعدادات لا تُطلب مصادقة."""
    assert client.get("/tools").status_code == 200


def test_api_key_required_when_set(client, monkeypatch):
    monkeypatch.setattr(settings, "API_KEY", "secret")
    assert client.get("/tools").status_code == 401  # بدون مفتاح
    assert client.get("/tools", headers={"X-API-Key": "wrong"}).status_code == 401
    assert client.get("/tools", headers={"X-API-Key": "secret"}).status_code == 200
    assert client.get("/tools?api_key=secret").status_code == 200  # عبر query (للـ <audio>)


def test_api_key_protects_chat(client, monkeypatch):
    monkeypatch.setattr(settings, "API_KEY", "secret")
    assert client.post("/chat", json={"message": "hi"}).status_code == 401
    r = client.post("/chat", json={"message": "hi"}, headers={"X-API-Key": "secret"})
    assert r.status_code == 200


def test_health_and_index_stay_public(client, monkeypatch):
    """فحص الصحة والواجهة لا يحتاجان مفتاحاً (لازمان لـ Docker healthcheck)."""
    monkeypatch.setattr(settings, "API_KEY", "secret")
    assert client.get("/health").status_code == 200
    assert client.get("/").status_code == 200


def test_websocket_rejected_without_key(client, monkeypatch):
    monkeypatch.setattr(settings, "API_KEY", "secret")
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect("/ws"):
            pass
    assert exc.value.code == 1008


def test_rate_limit_returns_429(client, monkeypatch):
    """بعد تجاوز الحد العام يعيد الخادم 429."""
    monkeypatch.setattr(settings, "RATE_LIMIT", "2/minute")
    assert client.get("/tools").status_code == 200
    assert client.get("/tools").status_code == 200
    assert client.get("/tools").status_code == 429


def test_chat_has_stricter_limit(client, monkeypatch):
    monkeypatch.setattr(settings, "CHAT_RATE_LIMIT", "1/minute")
    assert client.post("/chat", json={"message": "a"}).status_code == 200
    assert client.post("/chat", json={"message": "b"}).status_code == 429


def test_health_is_exempt_from_rate_limit(client, monkeypatch):
    monkeypatch.setattr(settings, "RATE_LIMIT", "1/minute")
    for _ in range(5):
        assert client.get("/health").status_code == 200
