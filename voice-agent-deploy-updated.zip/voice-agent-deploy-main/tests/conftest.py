# -*- coding: utf-8 -*-
"""
إعدادات pytest المشتركة.
الهدف: تشغيل الاختبارات بدون torch ولا GPU ولا Ollama، عبر Mocking لكل شيء ثقيل.
"""

import os
from unittest.mock import AsyncMock, MagicMock

import pytest

# يجب ضبطها قبل استيراد backend.main، كي لا يحاول الإقلاع تحميل النماذج
os.environ["PRELOAD_MODELS"] = "false"
os.environ["API_KEY"] = ""
os.environ["CORS_ORIGINS"] = "*"

from fastapi.testclient import TestClient  # noqa: E402

from backend import main as main_module  # noqa: E402
from backend.config import settings  # noqa: E402


@pytest.fixture(autouse=True)
def isolate_state(monkeypatch, tmp_path):
    """يعزل كل اختبار: يصفّر العدّادات والجلسات ويوجّه الملفات المؤقتة لمجلد مؤقت."""
    main_module.limiter.reset()  # تصفير عدّادات تحديد المعدل
    main_module._sessions.clear()  # حذف جلسات /chat
    monkeypatch.setattr(main_module, "TMP_DIR", tmp_path)
    # قيم افتراضية آمنة لكل اختبار (تُعدَّل داخل الاختبار عند الحاجة)
    monkeypatch.setattr(settings, "API_KEY", "")
    monkeypatch.setattr(settings, "RATE_LIMIT", "1000/minute")
    monkeypatch.setattr(settings, "CHAT_RATE_LIMIT", "1000/minute")


@pytest.fixture
def mock_llm(monkeypatch):
    """يستبدل LLM.chat برد ثابت بدل الاتصال بـ Ollama."""
    chat = AsyncMock(return_value="أهلاً بك")
    monkeypatch.setattr(main_module.LLM, "chat", chat)
    return chat


@pytest.fixture
def mock_models(monkeypatch):
    """يستبدل نماذج STT و TTS بكائنات وهمية (لا تحميل ولا GPU)."""
    stt = MagicMock()
    stt.transcribe_wav.return_value = "مرحبا"  # ما سيسمعه "النموذج"

    def fake_synthesize(text, ref_audio, ref_text, out_path):
        # نكتب ملفاً صغيراً بدل توليد صوت حقيقي
        with open(out_path, "wb") as f:
            f.write(b"RIFF....WAVE")
        return out_path, 24000

    tts = MagicMock()
    tts.synthesize.side_effect = fake_synthesize

    monkeypatch.setattr(main_module.loader, "load_stt", lambda: stt)
    monkeypatch.setattr(main_module.loader, "load_tts", lambda: tts)
    return stt, tts


@pytest.fixture
def client(mock_llm, mock_models):
    """عميل اختبار FastAPI (يشغّل lifespan أيضاً)."""
    with TestClient(main_module.app) as c:
        yield c
