# -*- coding: utf-8 -*-
"""اختبارات طبقة الأدوات (تعمل بدون أي نموذج)."""

from backend.llm import LLM
from backend.tools import tool_executor


def run(coro):
    """تشغيل coroutine داخل اختبار متزامن (دون الحاجة لـ pytest-asyncio)."""
    import asyncio

    return asyncio.run(coro)


def test_get_current_time():
    res = run(tool_executor.execute("get_current_time", {"timezone": "Africa/Algiers"}))
    assert res.success
    assert res.data["timezone"] == "Africa/Algiers"


def test_book_appointment_valid():
    args = {"patient_name": "أحمد علي", "date": "2026-11-01", "time": "09:30"}
    res = run(tool_executor.execute("book_appointment", args))
    assert res.success
    assert res.data["appointment"]["status"] == "مؤكد"


def test_book_appointment_invalid_date_fails_validation():
    args = {"patient_name": "أحمد", "date": "01/11/2026", "time": "09:30"}
    res = run(tool_executor.execute("book_appointment", args))
    assert not res.success
    assert "فشل التحقق" in res.error


def test_unknown_tool():
    res = run(tool_executor.execute("does_not_exist", {}))
    assert not res.success


def test_extract_tool_call_parses_json():
    call = LLM()._extract_tool_call('بعض النص {"tool": "get_current_time", "args": {}}')
    assert call == {"tool": "get_current_time", "args": {}}


def test_extract_tool_call_ignores_plain_text():
    assert LLM()._extract_tool_call("مرحباً بك") is None
    assert LLM()._extract_tool_call('{"name": "x"}') is None
